var searchData=
[
  ['logi_5fsal',['logi_sal',['../classcontrol_1_1funcional.html#a6a5da72315c267aca638656c89b3cac6',1,'control::funcional']]]
];
