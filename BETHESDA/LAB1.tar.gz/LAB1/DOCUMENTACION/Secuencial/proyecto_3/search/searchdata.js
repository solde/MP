var indexSectionsWithContent =
{
  0: "_abcdefhilmnoprstv",
  1: "_cefimprs",
  2: "ceipr",
  3: "ceimprs",
  4: "cdehilpr",
  5: "abcdefilmnoprstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Namespaces",
  3: "Archivos",
  4: "Funciones",
  5: "Variables"
};

