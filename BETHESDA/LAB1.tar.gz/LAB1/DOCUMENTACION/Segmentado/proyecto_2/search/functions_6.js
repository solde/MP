var searchData=
[
  ['reg_5festado',['reg_estado',['../classcontrol_1_1funcional.html#ab98b0ad9c467de5fa51722152d38ea6a',1,'control::funcional']]],
  ['resta',['resta',['../classsumador_1_1compor.html#a58cb97ec9b14c88cf3cdc2ecc3009599',1,'sumador::compor']]]
];
