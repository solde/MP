var indexSectionsWithContent =
{
  0: "_abcdefhilmnprstv",
  1: "_acdeimpr",
  2: "acipr",
  3: "acdeimpr",
  4: "aehilp",
  5: "abcdefilmnprstv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Namespaces",
  3: "Archivos",
  4: "Funciones",
  5: "Variables"
};

